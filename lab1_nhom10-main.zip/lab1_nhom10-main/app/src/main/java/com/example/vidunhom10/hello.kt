package com.example.vidunhom10

fun main()
{
    println("hom nay trời nhẹ lên cao")
    println("toi buồn hông hiểu vì sao tôi buồn")
    printHello()
}
fun printHello() {
    println ("Hello World")
}

